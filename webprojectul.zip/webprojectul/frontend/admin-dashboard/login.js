function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Hardcoded credentials for demo purposes
    if (username === 'admin' && password === 'admin123') {
        localStorage.setItem('isAuthenticated', 'true');
        window.location.href = 'admin.html'; // Redirect to dashboard
    } else {
        document.getElementById('error-message').innerText = 'Invalid username or password';
    }
}