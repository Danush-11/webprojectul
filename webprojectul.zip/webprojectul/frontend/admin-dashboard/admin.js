const token = 'YOUR_ADMIN_JWT_TOKEN'; // Replace with the actual token from login

// Fetch and display users
document.getElementById('fetchUsers').addEventListener('click', async () => {
  try {
    const response = await fetch('http://localhost:3000/api/users', {
      headers: {
        'Authorization': token,
      },
    });
    const users = await response.json();
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = `
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(user => `
            <tr>
              <td>${user._id}</td>
              <td>${user.name}</td>
              <td>${user.email}</td>
              <td>${user.role}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    console.error('Error fetching users:', error);
  }
});

// Fetch and display products
document.getElementById('fetchProducts').addEventListener('click', async () => {
  try {
    const response = await fetch('http://localhost:3000/api/products', {
      headers: {
        'Authorization': token,
      },
    });
    const products = await response.json();
    const productsList = document.getElementById('productsList');
    productsList.innerHTML = `
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody>
          ${products.map(product => `
            <tr>
              <td>${product._id}</td>
              <td>${product.name}</td>
              <td>$${product.price}</td>
              <td>${product.category}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (error) {
    console.error('Error fetching products:', error);
  }
});
// Fetch users from the backend
async function fetchUsers() {
  try {
      const response = await fetch('http://localhost:3000/api/users');
      if (!response.ok) throw new Error('Failed to fetch users');

      const users = await response.json();
      const userTableBody = document.querySelector('#userTable tbody');
      const totalUsers = document.getElementById('totalUsers');

      // Populate the table
      userTableBody.innerHTML = users.map(user => `
          <tr>
              <td>${user.id}</td>
              <td>${user.name}</td>
              <td>${user.email}</td>
              <td>${user.role}</td>
              <td>
                  <button onclick="editUser(${user.id})">Edit</button>
                  <button onclick="deleteUser(${user.id})">Delete</button>
              </td>
          </tr>
      `).join('');

      // Update total users
      totalUsers.textContent = users.length;
  } catch (error) {
      console.error('Error:', error);
      alert('Failed to load users.');
  }
}

// Open modal
function openModal() {
  document.getElementById('addUserModal').style.display = 'block';
}

// Close modal
function closeModal() {
  document.getElementById('addUserModal').style.display = 'none';
}

// Handle form submission
document.getElementById('addUserForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const newUser = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      role: document.getElementById('role').value
  };

  const response = await fetch('http://localhost:3000/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newUser)
  });

  if (response.ok) {
      fetchUsers(); // Refresh user list
      closeModal(); // Close modal
  }
});

// Logout functionality
function logout() {
  localStorage.removeItem('isAuthenticated');
  window.location.href = 'login.html';
}

// Call fetchUsers when the page loads
window.onload = fetchUsers;